# Pasir Wetan Growth Hub

Website pendamping UMKM makanan Desa Pasir Wetan (ACC #NextGreen Leaders Challenge 2026, tim RAWR).
Situs statis: HTML, CSS, dan JavaScript tanpa build. Demo asisten memakai aturan sederhana, belum terhubung ke API AI.

## Cara publikasi di GitHub Pages
1. Buat repository baru di GitHub, lalu upload semua isi folder ini (index.html, css, js, README.md).
2. Buka Settings > Pages.
3. Pada Build and deployment, pilih Deploy from a branch, branch main, folder /(root), lalu Save.
4. Tunggu 1 sampai 2 menit. Alamatnya https://USERNAME.github.io/NAMA-REPO/
