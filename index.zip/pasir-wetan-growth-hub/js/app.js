const $=s=>document.querySelector(s),rp=n=>'Rp'+Math.round(n).toLocaleString('id-ID');
const calm=matchMedia('(prefers-reduced-motion:reduce)').matches;
const hero=$('.hero');
if(!calm)hero.addEventListener('mousemove',e=>{const r=hero.getBoundingClientRect(),x=(e.clientX-r.left)/r.width-.5,y=(e.clientY-r.top)/r.height-.5;
document.querySelectorAll('.px').forEach(p=>{const d=+p.dataset.d;p.style.transform=`translate(${x*d}px,${y*d}px)`})});
if(!calm)document.querySelectorAll('.tilt').forEach(c=>{c.addEventListener('mousemove',e=>{const r=c.getBoundingClientRect();c.style.setProperty('--ry',((e.clientX-r.left)/r.width-.5)*9+'deg');c.style.setProperty('--rx',(.5-(e.clientY-r.top)/r.height)*9+'deg')});c.addEventListener('mouseleave',()=>{c.style.setProperty('--rx','0deg');c.style.setProperty('--ry','0deg')})});
const io=new IntersectionObserver(es=>es.forEach(e=>{if(e.isIntersecting){e.target.classList.add('in');io.unobserve(e.target)}}),{threshold:.15});
document.querySelectorAll('.card,.road li,.demo').forEach(el=>{el.classList.add('rv');io.observe(el)});
document.querySelectorAll('.tabs button').forEach(b=>b.onclick=()=>{document.querySelectorAll('.tabs button').forEach(x=>x.classList.toggle('on',x===b));document.querySelectorAll('.pn').forEach(p=>p.classList.toggle('on',p.id===b.dataset.p))});
const A={Produk:['Kemasan sudah menarik dan rapi','Nama dan label sudah konsisten','Legalitas usaha sudah diurus'],Pemasaran:['Dijual di lebih dari satu saluran','Rutin promosi di media sosial'],Keuangan:['Transaksi dicatat rutin','HPP sudah dihitung'],Pengetahuan:['Pernah belajar dari UMKM lain']};
const T={Produk:'perkuat kemasan dan label lebih dulu.',Pemasaran:'tambah satu saluran promosi yang mudah dikelola.',Keuangan:'mulai catat transaksi harian dan hitung HPP.',Pengetahuan:'dokumentasikan praktik usaha dan belajar dari UMKM benchmark.'};
let n=0,nm=[],prof=null;
$('#qs').innerHTML=Object.entries(A).map(([a,qs])=>qs.map(q=>{nm.push(a);return`<div class="q"><span>${q}</span><select id="q${n++}"><option value="0">Belum</option><option value="1">Sebagian</option><option value="2">Sudah</option></select></div>`}).join('')).join('');
$('#calc').onclick=()=>{const s={},m={};nm.forEach((a,i)=>{s[a]=(s[a]||0)+ +$('#q'+i).value;m[a]=(m[a]||0)+2});
const p=Object.keys(s).map(a=>[a,Math.round(s[a]/m[a]*100)]).sort((x,y)=>x[1]-y[1]);prof=p[0][0];
$('#res').innerHTML=p.map(([a,v])=>`<div class="rb"><div><span>${a}</span><b>${v}%</b></div><div class="bar"><i style="width:${v}%"></i></div></div>`).join('')+`<p><b>Prioritas: ${prof}.</b> Saran awal: ${T[prof]}</p>`};
const chat=$('#chat');
function msg(t,c){const d=document.createElement('div');d.className='m '+c;d.textContent=t;chat.append(d);chat.scrollTop=chat.scrollHeight}
function ans(q){q=q.toLowerCase();
if(/legal|pirt|halal|bpom|sertifikat|izin/.test(q))return'Saya tidak menentukan legalitas atau sertifikasi produk. Tanyakan persyaratan resminya ke dinas terkait atau pendamping desa.';
if(/gizi|kedaluwarsa|expired|tahan/.test(q))return'Klaim gizi dan masa kedaluwarsa memerlukan bukti, misalnya uji produk. Saya tidak memberi angka tanpa dasar itu.';
if(/vendor|supplier/.test(q))return'Saya tidak mengarang harga vendor. Minta penawaran tertulis dari dua atau tiga pemasok, lalu masukkan ke kalkulator HPP.';
if(/kemas|label|packag/.test(q))return'Tentukan berat bersih dan target konsumen, pilih kemasan yang melindungi dari lembap, lalu lengkapi label: nama produk, komposisi, berat bersih, dan kontak.';
if(/brand|nama|logo|identitas/.test(q))return'Mulai dari tiga hal: siapa pembelinya, apa ciri khas produk, dan nama yang mudah diingat. Samakan warna dan gaya tulisan di kemasan serta media sosial. Pemilik usaha perlu memeriksa semua usulan.';
if(/pasar|promo|jual|instagram|whatsapp|konten/.test(q))return'Pilih satu saluran dulu, misalnya WhatsApp Business atau Instagram. Buat tiga konten: foto produk, proses pembuatan, dan testimoni. Cantumkan kontak pemesanan.';
if(/catat|hpp|untung|laba|harga|kas|keuangan/.test(q))return'Catat setiap pemasukan dan pengeluaran, pisahkan uang usaha dari uang rumah tangga, lalu hitung HPP per bungkus sebelum menentukan harga jual. Coba tab Hitung HPP.';
if(/prioritas|langkah|perbaikan/.test(q))return prof?`Dari penilaian Anda, area ${prof} paling perlu diperkuat. Pilih satu tindakan kecil minggu ini lalu ukur hasilnya.`:'Isi tab Kesiapan dulu agar saran sesuai kondisi usaha.';
return'Saya belum punya panduan untuk pertanyaan itu. Coba tanya soal kemasan, branding, pemasaran, atau keuangan.'}
function ask(q){if(!q.trim())return;msg(q,'u');setTimeout(()=>msg(ans(q),'a'),350);$('#qi').value=''}
msg('Halo, saya Growth Assistant. Pilih pertanyaan di bawah atau tulis sendiri.','a');
['Bagaimana memperbaiki branding keripik pisang saya?','Apa isi label kemasan?','Bagaimana menghitung harga jual?','Apakah saya perlu izin PIRT?'].forEach(t=>{const b=document.createElement('button');b.type='button';b.textContent=t;b.onclick=()=>ask(t);$('#chips').append(b)});
$('#send').onclick=()=>ask($('#qi').value);$('#qi').onkeydown=e=>{if(e.key==='Enter')ask($('#qi').value)};
function hpp(){const g=i=>+$('#h'+i).value||0,t=g(1)+g(2)+g(3)+g(4),h=g(5)?t/g(5):0,s=h*(1+g(6)/100);$('#hr').innerHTML=`Total biaya ${rp(t)}<br>HPP per bungkus <b>${rp(h)}</b><br>Harga jual untuk target laba: <b>${rp(Math.ceil(s/100)*100)}</b>`}
document.querySelectorAll('.hg input').forEach(e=>e.oninput=hpp);hpp();
